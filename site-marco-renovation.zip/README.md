# Site Marco Rénovation

Site vitrine prêt pour GitHub + Vercel

## Déploiement
- Upload sur GitHub
- Connecter à Vercel
- Déploiement automatique
